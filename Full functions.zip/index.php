<h1>MySQL Functions Demonstration</h1>

<ul>
    <li><a href="String/list.php">String Functions (33)</a></li>
    <li><a href="Numeric/list.php">Numeric Functions (36)</a></li>
    <li><a href="Date/list.php">Date Functions (50)</a></li>
    <li><a href="advance/list.php">Advanced Functions (19)</a></li>
    <li><a href="https://www.w3schools.com/mysql/mysql_ref_functions.asp">W3schools MySQL Functions</a></li>
</ul>

